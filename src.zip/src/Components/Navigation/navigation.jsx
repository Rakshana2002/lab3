import React from 'react'
import {Link} from 'react-router-dom'
export default function Navigation(){
    return(
        <div>
            <nav className="menu">
                <div className="wrapper">
                    <ul>
                        <Link to="/business"> <li>Business news</li> </Link>
                    </ul>
                </div>
            </nav>
        </div>
    )
}