import React,{useSate, useEffect} from 'react';
import { getBusinessNews } from '../../API\'S/getBusinessNews';
function Business(){
    const [news,setNews]=useSate([]);
    useEffect(()=>{
        async function fetchData(){
            const result=await getBusinessNews()
            setNews(result);

        }
        fetchData();
    },[]);
    return (
        <ul>
            {news.map(article=>(
                <li key={article.title}>{article.title}</li>

            ))}
        </ul>
    );
 }