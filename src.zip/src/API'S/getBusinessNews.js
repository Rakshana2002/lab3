import axios from "axios";
const API="https://newsapi.org/v2/top-headlines?country=us&apiKey=afeeae62d5cf4bcdbbc0046b8026be09"
let data=null
export const getBusinessNews=async () =>{
    await axios.get(`${API}`).then(res=>{
        console.log(res.data.articles)
        data = res.data.articles;
    })
    .catch(err=>{
        console.log(err)
    })
    return data;
        
}